#!/bin/sh
#
# /****** Copyright Notice ***
# *
# * PIOK - Parallel I/O Kernels, Copyright (c) 2015-2016, 
# * The Regents of the University of California, through Lawrence
# * Berkeley National Laboratory (subject to receipt of any required
# * approvals from the U.S. Dept. of Energy).  All rights reserved.
# *
# * If you have questions about your rights to use or distribute this
# * software, please contact Berkeley Lab's Innovation & Partnerships Office
# * at  IPO@lbl.gov.
# *
# * NOTICE.  This Software was developed under funding from the U.S.
# * Department of Energy and the U.S. Government consequently retains
# * certain rights. As such, the U.S. Government has been granted for itself
# * and others acting on its behalf a paid-up, nonexclusive, irrevocable,
# * worldwide license in the Software to reproduce, distribute copies to the
# * public, prepare derivative works, and perform publicly and display
# * publicly, and to permit other to do so.
# *
# ****************************/
#
# Alex Sim <ASim@LBL.Gov>
# Scientific Data Management Group
# Lawrence Berkeley National Laboratory
# Thu Dec  1 12:41:41 PST 2016
#
# ./f4io_io_perf.sh 965992.output.txt
#
###################################################
# Update the LOCATIONs of the following two if not in the current dir
PARSERLOC="./f4io_darshanlog_parser_ioperf.py"
DARSHAN_LOG="darshan_all.txt"
###################################################

if [ ! -f "$PARSERLOC" ]; then
   echo "ERROR: Cannot find the f4io_darshanlog_parser_ioperf.py: $PARSERLOC"
   exit 1;
fi
if [ ! -f "$DARSHAN_LOG" ]; then
   echo "ERROR: Cannot find the darshan_all.txt: $DARSHAN_LOG"
   exit 1;
fi

if [ $# -gt 0 ]; then
	APP_LOG=$1
	FIO_LOG="./f4io.txt"
	echo "creating $FIO_LOG"
	grep LBNL_F4IO $APP_LOG > $FIO_LOG
	echo "creating io_perf.txt"
	python $PARSERLOC \
		-n 1 \
		-i $DARSHAN_LOG \
		-f $FIO_LOG \
		> ./io_perf.txt

	echo "creating io-plt000.txt for f4iot-plot-0.h5 from darshan log"
	grep f4iot-plot-0 $DARSHAN_LOG | grep \
	-e POSIX_OPENS \
	-e POSIX_WRITES \
	-e POSIX_SEEKS \
	-e POSIX_BYTES_WRITTEN \
	-e POSIX_MAX_BYTE_WRITTEN \
	-e POSIX_SEQ_WRITES \
	-e POSIX_MAX_WRITE_TIME_SIZE \
	-e POSIX_FSYNCS \
	-e POSIX_F_ \
	-e MPIIO_COLL_WRITES \
	-e MPIIO_INDEP_WRITES \
	-e MPIIO_COLL_WRITES \
	-e MPIIO_SYNCS \
	-e MPIIO_BYTES_WRITTEN \
	-e MPIIO_MAX_WRITE_TIME_SIZE \
	-e MPIIO_F_ \
	> io-plt0000.txt

	echo "creating io-chk0000.txt for f4iot-chkpt-0.h5 from darshan log"
	grep f4iot-chkpt-0 $DARSHAN_LOG | grep \
	-e POSIX_OPENS \
	-e POSIX_WRITES \
	-e POSIX_SEEKS \
	-e POSIX_BYTES_WRITTEN \
	-e POSIX_MAX_BYTE_WRITTEN \
	-e POSIX_SEQ_WRITES \
	-e POSIX_MAX_WRITE_TIME_SIZE \
	-e POSIX_FSYNCS \
	-e POSIX_F_ \
	-e MPIIO_COLL_WRITES \
	-e MPIIO_INDEP_WRITES \
	-e MPIIO_COLL_WRITES \
	-e MPIIO_SYNCS \
	-e MPIIO_BYTES_WRITTEN \
	-e MPIIO_MAX_WRITE_TIME_SIZE \
	-e MPIIO_F_ \
	> io-chk0000.txt
else
    echo $*
    echo "you must give exactly one parameters:"
    echo "./f4io_io_perf.sh PID.output"
	echo "  e.g. ./f4io_io_perf.sh 969935.output"
    exit 123;
fi



