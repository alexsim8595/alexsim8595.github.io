
#########################################################
## on ALCF (cetus for testing/debugging up to 1024 nodes and
            mira for production)
#########################################################
## To configure, generating Makefile on ALCF
## Required HDF5
##    If you don't have one, get /home/asim/hdf5-1816d3xll.tar.gz

% resoft
% soft add +mpiwrapper-xl.legacy-autoperf-latest
% which mpixlc_r
/soft/perftools/autoperf-20160802/scripts/xl.legacy/mpixlc_r

% ./configure \
--with-hdf5=/projects/ExaHDF5/FLASH/BGQ_PROD/run_asim_sedov/hdf5-1.8.16-d3xll-1608 \
--enable-alcf \
CC=mpixlc_r 

## With mpiP for MPI profiling.
##     If used, Darshan-3 is not going to work.
--with-mpip=/soft/perftools/mpiP 

## Shane's mpixlc_r which includes nightly built darshan-3
CC=/home/snyder/software/darshan/darshan3/install/wrappers/xl.legacy/mpixlc_r

## Built f4_io
make

## Running on ALCF
To run on cetus/mira, follow the below job submission script.
e.g. ALCF job submission to cetus for 32 nodes (512 cores) for 10 minutes

NODES=32
RANKS_PER_NODE=16
NPROCS=$((NODES*RANKS_PER_NODE)) 
PROJECT=Performance

qsub -A ExaHDF5 -n 32 --mode c16 -t 10  --env BG_THREADLAYOUT=2:BG_SHAREDMEMSIZE=32:BG_COREDUMPONERROR=1:OMP_NUM_THREADS=4:OMP_STACKSIZE=16M:L1P_POLICY=std:PAMID_VERBOSE=1:BGLOCKLESSMPIO_F_TYPE=0x47504653:AP_OUTPUT_LOCAL=1:MP_I_SHOW_AGGRS=1:GPFSMPIO_TIMING=1:ROMIO_PRINT_HINTS=1:DARSHAN_DISABLE_SHARED_REDUCTION=1:MPIP="-t 10.0 -k 2":HDF5_TRUNCATE=1:LBNL_LIMIT_AGGR=64:IO_HDF5_PARALLEL=1:H5_HAVE_PARALLEL=1 ./f4_io -t -c 512

# -c number_cores = nodes x 16
# -p for plain save all, 
#    but make the zone dimension (-z) small, otherwise memory can't handle

## Sample cobalt job script can be foudn: job_submit_alcf.sh

###########################################################
## Example job run and postprocessing for darshan on cetus/ALCF

$ ./job_submit_alcf.sh

$ qstat -u asim
JobID   User  WallTime  Nodes  State   Location  
=================================================
969935  asim  00:10:00  512    queued  None      
$ qstat -u asim
JobID   User  WallTime  Nodes  State    Location             
=============================================================
969935  asim  00:10:00  512    running  CET-40000-73331-512  

$ ls -l
-r--r-----  1 asim ExaHDF5     3396971 Dec  1 18:26
6523_f4_io_id969935_12-1-66342-9330441508375381706_1.darshan
-rw-r--r--  1 asim ExaHDF5        5879 Dec  1 18:27 969935.cobaltlog
-rw-r--r--  1 asim ExaHDF5        1409 Dec  1 18:27 969935.error
-rw-r--r--  1 asim ExaHDF5    20844935 Dec  1 18:26 969935.output
-rwxr-xr-x  1 asim ExaHDF5        1349 Dec  1 17:51 job_submit_alcf.sh*
-rw-r--r--  1 asim ExaHDF5        5576 Dec  1 18:26 ap-969935-1838910
-rwxr-xr-x  1 asim ExaHDF5    64159317 Dec  1 17:24 f4_io*
-rw-r--r--  1 asim ExaHDF5 96636770400 Dec  1 18:26 f4iot-chkpt-0.h5
-rw-r--r--  1 asim ExaHDF5 14495516768 Dec  1 18:25 f4iot-plot-0.h5

## ap-969935-1838910 is autoperf MPI sampling profiling output

## Darshan log path, sorted by data: /gpfs/mira-fs0/logs/darshan/mira/2016/

$ /home/snyder/software/darshan/darshan3/install/bin/darshan-job-summary.pl \
6523_f4_io_id969935_12-1-66342-9330441508375381706_1.darshan  \
--output darshan_sum.pdf

$ ll darshan_sum.pdf 
-rw-r--r-- 1 asim users 56778 Dec  1 18:34 darshan_sum.pdf

$ /home/snyder/software/darshan/darshan3/install/bin/darshan-parser \
--all 6523_f4_io_id969935_12-1-66342-9330441508375381706_1.darshan \
> darshan_all.txt

$ ll darshan_all.txt 
-rw-r--r--  1 asim ExaHDF5 441285994 Dec  1 18:37 darshan_all.txt

###########################################################
## For analysis of the logs, download my analysis tools from 
## http://sdm.lbl.gov/asim/docs/f4io-log-analyzer.tar.gz

## PID.output contains the application timing outputs
# e.g. grep timing logs for MPI rank 7620 and sample outputs
$ grep "\t7620\t" 969935.output.txt > 7620.txt
LBNL_F4IO_P	INIT_H5WP	7620	294912	36	274320	16
LBNL_F4IO_P	H5WriteP	7620	0.000791	294912	36	274320
LBNL_F4IO_P	H5Dwrite	7620	1.748987	274320
LBNL_F4IO_P	WRITE_PLOT	7620	2.520234	FILE_0	fio2	274320
LBNL_F4IO_C	INIT_H5WC	7620	294912	36	274320	16
LBNL_F4IO_C	H5WriteC	7620	0.000778	294912	36	274320
LBNL_F4IO_C	H5Dwrite	7620	3.248891	274320
LBNL_F4IO_C	WRITE_CHKPT	7620	4.273560	FILE_0	fio0	274320

H5Dwrite is the time taken for H5Dwrite().
WRITE_PLOT and WRITE_CHKPT are the times taken for each iteration.

## To calculate IO performance 
##    based on application timing log and darshan-3 output
##    assuming you have darshan_all.txt already
# ./f4io_io_perf.sh PID.output
e.g.
$ ./f4io_io_perf.sh 969935.output
It creates io_perf.txt

## analysis sample is here:
https://sdm.lbl.gov/asim/docs/io_perf.txt

## If you have Spark running, you can run this to generate a plot
f4io_darshan3_plots.ipynb

# Example plots:
# For larger file, similar to checkpoint files
http://sdm.lbl.gov/asim/docs/fio-io-chk0000_fio_s.png
# For smaller file, similar to plot files
http://sdm.lbl.gov/asim/docs/fio-io-plt0000_fio_s.png

###########################################################
## For Local Mac

% module load hdf5
% module load autoconf
% autoreconf --force --verbose

% ./configure --with-hdf5=/usr/local/pkg/hdf5/1.8.16-mpich \
--with-mpi=/usr/local/pkg/mpich/3.2 \
CC=mpicc CXX=mpic++

# To run on Mac, 2 cores
% mpirun -disable-hostname-propagation -np 2 ./f4_io -c 2

