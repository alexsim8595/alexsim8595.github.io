/****** Copyright Notice ***
 *
 * PIOK - Parallel I/O Kernels, Copyright (c) 2015-2016, 
 * The Regents of the University of California, through Lawrence
 * Berkeley National Laboratory (subject to receipt of any required
 * approvals from the U.S. Dept. of Energy).  All rights reserved.
 *
 * If you have questions about your rights to use or distribute this
 * software, please contact Berkeley Lab's Innovation & Partnerships Office
 * at  IPO@lbl.gov.
 *
 * NOTICE.  This Software was developed under funding from the U.S.
 * Department of Energy and the U.S. Government consequently retains
 * certain rights. As such, the U.S. Government has been granted for itself
 * and others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, distribute copies to the
 * public, prepare derivative works, and perform publicly and display
 * publicly, and to permit other to do so.
 *
 ****************************/
/*
// Description: 
//     This is a simple IO benchmark based on flash4 io characteristics
// Alex Sim <ASim@lbl.gov>
// Scientific Data Management Group
// Lawrence Berkeley National Laboratory, Berkeley, CA
// Thu Dec  1 10:15:18 PST 2016
// 
// application on 512 nodes = 8192 cores on cetus
//
// 6 checkpointing files = called 60 times = 10 variables per file
//    10 vars = dens, eint, ener, gamc, game, pres, temp, velx, vely, velz
//    Number of zones x, y, z = 16
//    total blocks = io_splitNumBlks = 299592
//    local blocks = localNumBlocks = 36
//    double* unknowns = [1][NZB][NYB][NXB][var]
//    file size = 38*16*16*16 * 10 * 8192 * 8 = 96636764160
//
// 12 plot files = called 36 times = 3 variables per file
//    3 vars = dens, pres, temp
//    Number of zones x, y, z = 16
//    total blocks = io_splitNumBlks = 299592
//    local blocks = localNumBlocks = 38
//    float* unknowns = [1][NZB][NYB][NXB][nvar]
//    file size = 38*16*16*16 * 3 * 8192 * 4 = 15300820992
//
// 98289582080 sedov_hdf5_chk_0000 - 005
// 14830141440 sedov_hdf5_plt_cnt_0000 - 0010, sedov_forced_hdf5_plt_cnt_0000
//
// This program creates two files, each similar to plot and checkpoint file size: 
//    96636770400 bytes for f4iot-chkpt-0.h5
//    14495516768 bytes for f4iot-plot-0.h5 
//    # 14495516768 = 36*16*16*16 *3*4 *8192
//    # plotfile_size = 14495516768;
//    # percall_size = pfile_size/(numcores*12);
//    # total_blocks = percall_size / numcores; 
//    # local_blocks = total_blocks / (nxb*nyb*nzb);
//    # for 8192 cores, local_blocks=2, nxb=2
//
// To run on Mac, 2 cores
//    mpirun -disable-hostname-propagation -np 2 ./f4_io -c 2
//
// To run on cetus/mira, follow the below job submission script.
// e.g. ALCF job submission for 32 nodes (512 cores) for 10 minutes
NODES=32
RANKS_PER_NODE=16
NPROCS=$((NODES*RANKS_PER_NODE)) 
PROJECT=Performance

qsub -A ExaHDF5 -n 32 --mode c16 -t 10  --env BG_THREADLAYOUT=2:BG_SHAREDMEMSIZE=32:BG_COREDUMPONERROR=1:OMP_NUM_THREADS=4:OMP_STACKSIZE=16M:L1P_POLICY=std:PAMID_VERBOSE=1:BGLOCKLESSMPIO_F_TYPE=0x47504653:AP_OUTPUT_LOCAL=1:MP_I_SHOW_AGGRS=1:GPFSMPIO_TIMING=1:ROMIO_PRINT_HINTS=1:DARSHAN_DISABLE_SHARED_REDUCTION=1:MPIP="-t 10.0 -k 2":HDF5_TRUNCATE=1:LBNL_LIMIT_AGGR=64:IO_HDF5_PARALLEL=1:H5_HAVE_PARALLEL=1 ./f4_io -t -c 512

# f4_io -c number_cores = nodes x 16
//
*/

#include <hdf5.h>
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdbool.h>
#include <sys/time.h>

const char usage[] = "usage:  f4_io [-options ...]\n\n\
where options include:\n\
  -h/help\n\
  -v/version\n\
  -a/aggr : number of aggregators for GPFS (default system dependent)\n\
  -b/blocksize : number of local blocks (default 36) \n\
  -c/coresize : number of cores (default 8192) \n\
  -d/debug : debug flag (default false) \n\
  -f/fileprefix : output file prefix (default f4iot) \n\
  -n/numfile : number of output files (default 1) \n\
  -p/plain : no hdf5 hyperslab selection (default false) \n\
  -t/timing : measure timing (default false) \n\
  -z/zone : number of zones for dimensions (default 16) \n\
\n";

float timer_off(struct timeval* before) {
	struct timeval result, now;
	float myelapsed=0.0;
	gettimeofday (&now, NULL);
    result.tv_sec = now.tv_sec - before->tv_sec;
    result.tv_usec = now.tv_usec - before->tv_usec;	
    if (result.tv_usec < 0) {
        --(result.tv_sec);
        result.tv_usec += 1000000;
    }
	myelapsed = (float) result.tv_sec+ (float) (result.tv_usec)/1000000.0; 
	return myelapsed;
}

double uniform_random_number() {
	return (((double)rand())/((double)(RAND_MAX)));
}

int fio_h5write_plot(hid_t file_identifier,
					int nxb,             /* # of zones to store in x */
					int nyb,             /* # of zones to store in y */
					int nzb,             /* # of zones to store in z */
					char* record_label, 
					int local_blocks,   /* localNumBlocks */
					int total_blocks,   /* io_splitNumBlks */
					int global_offset,  /* localOffset */
					float* unknowns,
					bool timingFlag,
					bool plainFlag) 
{
    struct timeval start_time;
    float elapsed=0.0;
    hid_t dataspace, dataset_plist, dataset, memspace, dxfer_template;
    herr_t status, herr;
    int rank;
    hsize_t dimens_4d[4], dimens_5d[5];
    hsize_t start_4d[4];
    hsize_t stride_4d[4], count_4d[4];
	hsize_t dimens_chunk[4];
	char record_label_new[5];
    const int dims = 1;
    const int diskSize[] = {1};
    int parallelIO=1;
    int my_rank;
	float* unknowns_plots;
	int unknown_size=0, i=0;
	
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    strncpy(record_label_new, record_label,4);
    *(record_label_new + 4) = '\0';
	
    printf ("LBNL_F4IO_P\tINIT_H5WP\t%d\t%d\t%d\t%d\t%d\n", my_rank, total_blocks, local_blocks, global_offset,nxb);

    /* plot files: set the dimensions of the dataset */
    rank = 4;
	if (plainFlag)
		dimens_4d[0] = local_blocks;
	else
    	dimens_4d[0] = total_blocks;
    dimens_4d[1] = nzb;
    dimens_4d[2] = nyb;
    dimens_4d[3] = nxb;
	
	gettimeofday(&start_time, NULL);
	dataspace = H5Screate_simple(rank, dimens_4d, NULL);
	dataset_plist = H5Pcreate(H5P_DATASET_CREATE);
	
    dataset = H5Dcreate(file_identifier, record_label_new, H5T_NATIVE_FLOAT, dataspace, dataset_plist);
	// H5_DLL hid_t H5Dcreate1(hid_t file_id, const char *name, hid_t type_id,
    //           hid_t space_id, hid_t dcpl_id);
	// H5_DLL hid_t H5Dcreate2(hid_t loc_id, const char *name, hid_t type_id,
    //           hid_t space_id, hid_t lcpl_id, hid_t dcpl_id, hid_t dapl_id);
	// H5Dcreate calls H5Dcreate1 on ALCF, H5Dcreate2 on Mac
	//           use -DH5_USE_16_API for H5Dcreate1 on Mac

	// create the hyperslab 
	start_4d[0] = (hsize_t) (global_offset);
	start_4d[1] = 0;
	start_4d[2] = 0;
	start_4d[3] = 0;
    
	stride_4d[0] = 1;
	stride_4d[1] = 1;
	stride_4d[2] = 1;  
	stride_4d[3] = 1;
   
	count_4d[0] = (hsize_t) (local_blocks);
	count_4d[1] = nzb;
	count_4d[2] = nyb;
	count_4d[3] = nxb;
		
	status = H5Sselect_hyperslab(dataspace, H5S_SELECT_SET, start_4d, stride_4d, count_4d, NULL);
	
	// create the memory space 
	rank = 5;
	dimens_5d[0] = (hsize_t) local_blocks;
	dimens_5d[1] = nzb;
	dimens_5d[2] = nyb;
	dimens_5d[3] = nxb;
	dimens_5d[4] = 1;
	
	memspace = H5Screate_simple(rank, dimens_5d, NULL);

    dxfer_template = H5Pcreate(H5P_DATASET_XFER);
	herr = H5Pset_dxpl_mpio(dxfer_template, H5FD_MPIO_COLLECTIVE);
    if (timingFlag) {
        elapsed=timer_off(&start_time);
        printf ("LBNL_F4IO_P\tH5WriteP\t%d\t%f\t%d\t%d\t%d\n", my_rank, elapsed, total_blocks, local_blocks, global_offset);
    }
	
    /*
    // write the data
 	// COLLECTIVE IO does not like H5S_ALL, H5S_ALL for memspace and data space.
 	// When H5P_DEFAULT is used, H5S_ALL overwrites each other.
 	// COLLECTIVE IO for all mem space matching data space and dataset doesn't work
 	// 		for default 36x16x16x16 case
 	// COLLECTIVE IO with H5S_ALL worked for 36x8x8x8
 	// 		However file size is much smaller at 36x8x8x8x4
 	// 		It might know they are all from the offset 0.
    */
    gettimeofday(&start_time, NULL);
    if (plainFlag)
		status = H5Dwrite(dataset, H5T_NATIVE_FLOAT, H5S_ALL, H5S_ALL, dxfer_template, unknowns);
    else
    	status = H5Dwrite(dataset, H5T_NATIVE_FLOAT, memspace, dataspace, dxfer_template, unknowns);
    if (timingFlag) {
        elapsed=timer_off(&start_time);
        printf ("LBNL_F4IO_P\tH5Dwrite\t%d\t%f\t%d\n", my_rank, elapsed, global_offset);
    }

    H5Pclose(dxfer_template);
    H5Sclose(memspace);
    H5Pclose(dataset_plist);
    H5Sclose(dataspace);
    H5Dclose(dataset);
	
	return 0;
}

int fio_h5write_checkpt(hid_t file_identifier,
						int nxb,             /* # of zones to store in x */
						int nyb,             /* # of zones to store in y */
						int nzb,             /* # of zones to store in z */
						char* record_label, 
						int local_blocks,   /* localNumBlocks */
						int total_blocks,   /* io_splitNumBlks */
						int global_offset,  /* localOffset */
						double* unknowns,
						bool timingFlag,
						bool plainFlag) 
{
    struct timeval start_time;
    float elapsed=0.0;
    hid_t dataspace, dataset_plist, dataset, memspace, dxfer_template;
    herr_t status, herr;
    int rank;
    hsize_t dimens_4d[4], dimens_5d[5];
    hsize_t start_4d[4];
    hsize_t stride_4d[4], count_4d[4];
	hsize_t dimens_chunk[4];
	char record_label_new[5];
    const int dims = 1;
    const int diskSize[] = {1};
    int parallelIO=1;
    int my_rank;

    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    strncpy(record_label_new, record_label,4);
    *(record_label_new + 4) = '\0';

    printf ("LBNL_F4IO_C\tINIT_H5WC\t%d\t%d\t%d\t%d\t%d\n", my_rank, total_blocks, local_blocks, global_offset,nxb);

    /* plot files: set the dimensions of the dataset */
    rank = 4;
	if (plainFlag)
		dimens_4d[0] = local_blocks;
	else
    	dimens_4d[0] = total_blocks;
    dimens_4d[1] = nzb;
    dimens_4d[2] = nyb;
    dimens_4d[3] = nxb;

	gettimeofday(&start_time, NULL);
	dataspace = H5Screate_simple(rank, dimens_4d, NULL);
	dataset_plist = H5Pcreate(H5P_DATASET_CREATE);

    dataset = H5Dcreate(file_identifier, record_label_new, H5T_NATIVE_DOUBLE, dataspace, dataset_plist);
	// H5_DLL hid_t H5Dcreate1(hid_t file_id, const char *name, hid_t type_id,
    //           hid_t space_id, hid_t dcpl_id);
	// H5_DLL hid_t H5Dcreate2(hid_t loc_id, const char *name, hid_t type_id,
    //           hid_t space_id, hid_t lcpl_id, hid_t dcpl_id, hid_t dapl_id);
	// H5Dcreate calls H5Dcreate1 on ALCF, H5Dcreate2 on Mac
	//           use -DH5_USE_16_API for H5Dcreate1 on Mac

	// create the hyperslab
    start_4d[0] = (hsize_t) (global_offset);
    start_4d[1] = 0;
    start_4d[2] = 0;
    start_4d[3] = 0;

    stride_4d[0] = 1;
    stride_4d[1] = 1;
    stride_4d[2] = 1;  
    stride_4d[3] = 1;

    count_4d[0] = (hsize_t) (local_blocks);
    count_4d[1] = nzb;
    count_4d[2] = nyb;
    count_4d[3] = nxb;

    status = H5Sselect_hyperslab(dataspace, H5S_SELECT_SET, start_4d, stride_4d, count_4d, NULL);
	
	rank = 5;
	dimens_5d[0] = (hsize_t) local_blocks;
	dimens_5d[1] = nzb;
	dimens_5d[2] = nyb;
	dimens_5d[3] = nxb;
	dimens_5d[4] = 1;

	// create the memory space
	memspace = H5Screate_simple(rank, dimens_5d, NULL);
	
    dxfer_template = H5Pcreate(H5P_DATASET_XFER);
	herr = H5Pset_dxpl_mpio(dxfer_template, H5FD_MPIO_COLLECTIVE);
    if (timingFlag) {
        elapsed=timer_off(&start_time);
        printf ("LBNL_F4IO_C\tH5WriteC\t%d\t%f\t%d\t%d\t%d\n", my_rank, elapsed, total_blocks, local_blocks, global_offset);
    }
	
    // write the data
    gettimeofday(&start_time, NULL);
	if (plainFlag)
		status = H5Dwrite(dataset, H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, dxfer_template, unknowns);
	else
    	status = H5Dwrite(dataset, H5T_NATIVE_DOUBLE, memspace, dataspace, dxfer_template, unknowns);
    if (timingFlag) {
        elapsed=timer_off(&start_time);
        printf ("LBNL_F4IO_C\tH5Dwrite\t%d\t%f\t%d\n", my_rank, elapsed, global_offset);
    }

	//H5Fflush(file_identifier,H5F_SCOPE_GLOBAL);
    H5Pclose(dxfer_template);
    H5Sclose(memspace);
    H5Pclose(dataset_plist);
    H5Sclose(dataspace);
    H5Dclose(dataset);

	return 0;
}

int main (int argc, char* argv[]) {
	struct timeval start_time;
	float elapsed=0.0;
	char filename_prefix[128];
	char filename_plot[128], filename_chkpt[128];
	int i=0, j=0;
 	char aggrnum[16]; 
	bool aggrFlag=false;
	int ierr;
	MPI_Info FILE_INFO_TEMPLATE;
	int my_rank, num_procs;
	bool debugFlag=false;
	bool timingFlag=false;
	bool plainFlag=false;	// no hyperslab for HDF5 write
	int coresize = 8192;	// 512 nodes x 16 cores = 8192 cores
	int nxb=16;            // # of zones to store in x 
	int nyb=16;            // # of zones to store in y 
	int nzb=16;            // # of zones to store in z 
	int local_blocks=36;  	// localNumBlocks (org=36,37,38)
	int total_blocks=294912;	// 36*8192 io_splitNumBlks (org=299592)
	int unknown_size=0;	// array size
	int global_offset=0;
	int nvp = 3; // nvar for plots = 3
	int nvc = 10; // nvar for checkpts = 10
	float* unknowns_plots;   // [mblk][NZB][NYB][NXB][nvar] nvar=3
	double* unknowns_chkpt;   // [1][NZB][NYB][NXB][nvar] nvar=10
	char record_label[5]; 
    hid_t acc_template, file_identifier_plot, file_identifier_chkpt;
    herr_t status, herr;
	int numfiles = 1;
	sprintf(filename_prefix, "f4iot");

    for (int i=1 ; i < argc; i++) {
        if (argv[i][0] != '-') {
            printf("%s : error, unknown argument %s\n%s",
                        argv[0],argv[i],usage);
            exit(1);
        }
        else {
            switch (argv[i][1]) {
                case 'h' :
                    if (!strcmp(argv[i], "-help") ||
						!strcmp(argv[i], "-h")) {
                        fprintf(stderr,"%s [options]\n",argv[0]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    else {
                        fprintf(stderr,"%s [options]\n",argv[i]);
                        fprintf(stderr,"%s",usage);
                        exit(1);
                    }
                    break;
				case 'a':
	                    if (!strcmp(argv[i], "-aggr") ||
						    !strcmp(argv[i], "-a")) {
							//aggrnum=atoi(argv[i]);
							strcpy(aggrnum, argv[++i]);
							aggrFlag = true;
	                    }
	                    else {
	                        fprintf(stderr,"%s [options]\n",argv[i]);
	                        fprintf(stderr,"%s",usage);
	                        exit(1);
	                    }
	                    break;
				case 'b':
	                    if (!strcmp(argv[i], "-blocksize") ||
						    !strcmp(argv[i], "-b")) {
							local_blocks=atoi(argv[++i]);
	                    }
	                    else {
	                        fprintf(stderr,"%s [options]\n",argv[i]);
	                        fprintf(stderr,"%s",usage);
	                        exit(1);
	                    }
	                    break;
				case 'c':
	                    if (!strcmp(argv[i], "-coresize") ||
						    !strcmp(argv[i], "-c")) {
							coresize=atoi(argv[++i]);
	                    }
	                    else {
	                        fprintf(stderr,"%s [options]\n",argv[i]);
	                        fprintf(stderr,"%s",usage);
	                        exit(1);
	                    }
	                    break;
				case 'd':
	                    if (!strcmp(argv[i], "-debug") ||
						    !strcmp(argv[i], "-d")) {
	                        debugFlag=true;
	                    }
	                    else {
	                        fprintf(stderr,"%s [options]\n",argv[i]);
	                        fprintf(stderr,"%s",usage);
	                        exit(1);
	                    }
	                    break;
				case 'f':
	                    if (!strcmp(argv[i], "-fileprefix") ||
						    !strcmp(argv[i], "-f")) {
	                        strcpy(filename_prefix, argv[++i]);
	                    }
	                    else {
	                        fprintf(stderr,"%s [options]\n",argv[i]);
	                        fprintf(stderr,"%s",usage);
	                        exit(1);
	                    }
	                    break;
				case 'n':
	                    if (!strcmp(argv[i], "-numfile") ||
						    !strcmp(argv[i], "-n")) {
	                        numfiles=atoi(argv[++i]);
	                    }
	                    else {
	                        fprintf(stderr,"%s [options]\n",argv[i]);
	                        fprintf(stderr,"%s",usage);
	                        exit(1);
	                    }
	                    break;
				case 'p':
	                    if (!strcmp(argv[i], "-plain") ||
						    !strcmp(argv[i], "-p")) {
	                        plainFlag=true;
	                    }
	                    else {
	                        fprintf(stderr,"%s [options]\n",argv[i]);
	                        fprintf(stderr,"%s",usage);
	                        exit(1);
	                    }
	                    break;
				case 't':
	                    if (!strcmp(argv[i], "-timing") ||
						    !strcmp(argv[i], "-t")) {
	                        timingFlag=true;
	                    }
	                    else {
	                        fprintf(stderr,"%s [options]\n",argv[i]);
	                        fprintf(stderr,"%s",usage);
	                        exit(1);
	                    }
	                    break;
				case 'z':
	                    if (!strcmp(argv[i], "-zone") ||
						    !strcmp(argv[i], "-z")) {
	                        nxb = atoi(argv[++i]);
	                        nyb = nxb;
	                        nzb = nxb;
	                    }
	                    else {
	                        fprintf(stderr,"%s [options]\n",argv[i]);
	                        fprintf(stderr,"%s",usage);
	                        exit(1);
	                    }
	                    break;
                default :
                    fprintf(stderr,"%s [options]\n",argv[i]);
                    fprintf(stderr,"%s",usage);
                    exit(1);
                    break;
            }
        }
    }
	
	total_blocks = local_blocks * coresize;
	if (plainFlag)
		unknown_size = local_blocks*nxb*nyb*nzb;
	else
		unknown_size = total_blocks;
		
	MPI_Init(&argc,&argv);
	MPI_Comm_rank (MPI_COMM_WORLD, &my_rank);
	MPI_Comm_size (MPI_COMM_WORLD, &num_procs);

	/* // sample
	float* unknowns,   // [mblk][NZB][NYB][NXB][nvar] nvar=3
	double* unknowns,   // [1][NZB][NYB][NXB][nvar] nvar=10
	if (timingFlag) {
		gettimeofday(&start_time, NULL);
	    elapsed=timer_off(&start_time);
	    printf ("LBNL_F4IO\tINIT\t%d\t%f\t%d\t%d\n", my_rank, elapsed,local_blocks, total_blocks);
	}
    */
	
	if (my_rank == 0) printf ("LBNL_F4IO\tNUM_PARTICLES\t%d\tLOCAL_BLOCKS\t%dZONE_DIM\t%d\tNUM_CORE\t%d\n", total_blocks, local_blocks, nxb, coresize);

	//gettimeofday(&start_time, NULL);
	unknowns_plots=(float*)malloc(unknown_size*sizeof(float));
	unknowns_chkpt=(double*)malloc(unknown_size*sizeof(double));
	for (i=0; i<unknown_size; i++) 	{
		unknowns_plots[i] = (float) uniform_random_number()*local_blocks;
		unknowns_chkpt[i] = (double) uniform_random_number()*local_blocks;
	}
	/*
	if (timingFlag) {
	    elapsed=timer_off(&start_time);
	    printf ("LBNL_F4IO\tINIT\t%d\t%f\t%d\t%d\t%d\t%d\n", my_rank, elapsed,total_blocks, local_blocks, unknown_size, nxb);
	}
	*/

    if (my_rank == 0) printf ("LBNL_F4IO\tINIT\t%d\t%d\t%d\t%d\t%d\n", my_rank, total_blocks, local_blocks, unknown_size, nxb);
	
	/* // setting the number of aggregator for GPFS at ALCF
    if (getenv("ALCF_LIMIT_AGGR")) {
		numaggr = atoi(getenv("LBNL_LIMIT_AGGR"));
		printf("ALCF: MPI-IO LIMIT NUM of AGGR: %d\n", numaggr);
		ierr = MPI_Info_set(FILE_INFO_TEMPLATE, "bg_nodes_pset", getenv("ALCF_LIMIT_AGGR"));
	}
	*/
	
	for (i=0; i<numfiles; i++) {
		sprintf(filename_plot, "%s-plot-%d.h5", filename_prefix, i);
		sprintf(filename_chkpt, "%s-chkpt-%d.h5", filename_prefix, i);

		if (my_rank == 0) printf ("LBNL_F4IO\tFILEIO_START\t%d\t%d\n", my_rank, i);
		
		// Limit Aggregator for GPFS at ALCF
		acc_template = H5Pcreate(H5P_FILE_ACCESS);
		if (aggrFlag) {
			MPI_Info_create(&FILE_INFO_TEMPLATE);
			ierr = MPI_Info_set(FILE_INFO_TEMPLATE, "bg_nodes_pset", aggrnum);
			ierr = H5Pset_fapl_mpio(acc_template, MPI_COMM_WORLD, FILE_INFO_TEMPLATE);
		}
		else {
	        H5Pset_fapl_mpio(acc_template, MPI_COMM_WORLD, MPI_INFO_NULL);
		}
		
		file_identifier_plot = H5Fcreate(filename_plot, H5F_ACC_TRUNC, H5P_DEFAULT, acc_template);
		file_identifier_chkpt = H5Fcreate(filename_chkpt, H5F_ACC_TRUNC, H5P_DEFAULT, acc_template);
		
		// H5Fopen(filename_plot, H5F_ACC_RDWR, acc_template);
		// H5Fopen(filename_chkpt, H5F_ACC_RDWR, acc_template);
		
		if (plainFlag)
			global_offset = 0;
		else 
			global_offset = my_rank * local_blocks;

		// do h5write with # of vars in the record_label
		// for plots, 3 vars: dens, pres, temp
		for (j=0; j<nvp; j++) {
			sprintf(record_label , "fio%d", j);
			gettimeofday(&start_time, NULL);
			fio_h5write_plot(file_identifier_plot,
						nxb,           
						nyb,            
						nzb,
						record_label,
						local_blocks,  
						total_blocks,
						global_offset,
						unknowns_plots,
						timingFlag,
						plainFlag);
			if (timingFlag) {
			    elapsed=timer_off(&start_time);
			    printf ("LBNL_F4IO_P\tWRITE_PLOT\t%d\t%f\tFILE_%d\t%s\t%d\n",  my_rank, elapsed,i,record_label, global_offset);
			}
		}
		H5Fclose(file_identifier_plot);

		// for chkpt, 10 vars
		// dens, eint, ener, gamc, game, pres, temp, velx, vely, velz
		for (j=0; j<nvc; j++) {
			sprintf(record_label , "fio%d", j);
			gettimeofday(&start_time, NULL);
			fio_h5write_checkpt(file_identifier_chkpt,
						nxb,           
						nyb,            
						nzb,
						record_label,
						local_blocks,  
						total_blocks,
						global_offset,
						unknowns_chkpt,
						timingFlag,
						plainFlag);
			if (timingFlag) {
			    elapsed=timer_off(&start_time);
			    printf ("LBNL_F4IO_C\tWRITE_CHKPT\t%d\t%f\tFILE_%d\t%s\t%d\n", my_rank, elapsed,i,record_label, global_offset);
			}
		}	
		H5Fclose(file_identifier_chkpt);

		H5Pclose(acc_template);
		if (aggrFlag) MPI_Info_free(&FILE_INFO_TEMPLATE);
		//MPI_Barrier (MPI_COMM_WORLD);

		if (my_rank == 0) printf ("LBNL_F4IO\tFILEIO_DONE\t%d\t%d\n", my_rank, i);
	}
	
	MPI_Barrier (MPI_COMM_WORLD);
	free(unknowns_plots); 
	free(unknowns_chkpt); 
	MPI_Finalize();

	return 0;
}
