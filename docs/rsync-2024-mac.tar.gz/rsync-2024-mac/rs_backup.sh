#!/bin/bash

# Disc backup script: Requires rsync 3

# Ask for the administrator password upfront
sudo -v

# IMPORTANT: Make sure you update the `DST` variable to match the name of the
# destination backup drive

DST="/Volumes/BACKUP2017/"
EXCLUDE="$HOME/.backup_ignore"
SRC="/"

PROG=$0

if [ ! -r "$SRC" ]; then
    logger -t $PROG "Source $SRC not readable - Cannot start the sync process"
    exit;
fi

if [ ! -w "$DST" ]; then
    logger -t $PROG "Destination $DST not writeable - Cannot start the sync process"
    exit;
fi

# To save the log into /usr/local/logs
MYDATE=`date +"%F-%H%M"`
BACKUPLOG="/usr/local/logs/backup-$MYDATE.txt"

# If you want to log to the system, uncomment the next line
# logger -t $PROG "Start rsync"
echo "Start rsync"

# add --dry-run if you want to test out first

sudo /usr/local/bin/rsync --acls \
           --archive \
           --delete \
           --delete-excluded \
           --exclude-from=$EXCLUDE \
           --hard-links \
           --links \
           --one-file-system \
           --sparse \
           --verbose \
           --xattrs \
           --log-file=$BACKUPLOG \
           "$SRC" "$DST"

# If you want to log to the system, uncomment the next line
# logger -t $PROG "End rsync"
echo "End rsync"

# Make the backup bootable
sudo bless -folder "$DST"/System/Library/CoreServices

exit 0
