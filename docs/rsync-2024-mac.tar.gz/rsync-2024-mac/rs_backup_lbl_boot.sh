#!/bin/bash

# Disc backup script: Requires rsync 3

# Ask for the administrator password upfront
sudo -v

# IMPORTANT: Make sure you update the `DST` variable to match the name of the
# destination backup drive

DST="/Volumes/BKUP2017SIMLBL/"
SRC="/"
EXCLUDE="$HOME/.backup_ignore_lbl"

PROG=$0

# --acls        update the destination ACLs to be the same as the source ACLs
# --archive     turn on archive mode (recursive copy + retain attributes)
# --delete      delete any files that have been deleted locally
# --delete-excluded   delete any files (on DST) that are part of the list of excluded files
# --exclude-from  reference a list of files to exclude
# --hard-links    preserve hard-links
# --one-file-system   don't cross device boundaries (ignore mounted volumes)
# --sparse      handle sparse files efficiently
# --verbose     increase verbosity
# --xattrs		update the remote extended attributes to be the same as the local ones
# --dry-run		dry run

if [ ! -r "$SRC" ]; then
    logger -t $PROG "Source $SRC not readable - Cannot start the sync process"
    exit;
fi

if [ ! -w "$DST" ]; then
    logger -t $PROG "Destination $DST not writeable - Cannot start the sync process"
    exit;
fi

# To save the log into /usr/local/logs
MYDATE=`date +"%F-%H%M"`
BACKUPLOG="/usr/local/logs/backup-$MYDATE.txt"

# If you want to log to the system, uncomment the next line
# logger -t $PROG "Start rsync"
echo "Start rsync"

# add --dry-run if you want to test first
sudo /usr/local/bin/rsync --acls \
           --archive \
           --delete \
           --delete-excluded \
           --exclude-from=$EXCLUDE \
           --hard-links \
           --links \
           --one-file-system \
           --sparse \
           --verbose \
           --xattrs \
           --log-file=$BACKUPLOG \
           "$SRC" "$DST"

# If you want to log to the system, uncomment the next line
# logger -t $PROG "End rsync"
echo "End rsync"

# Make the backup bootable
sudo bless -folder "$DST"/System/Library/CoreServices

echo "blessed destination"

exit 0
