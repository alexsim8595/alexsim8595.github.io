#!/bin/bash

# Disc backup script: Requires rsync 3

# Ask for the administrator password upfront
sudo -v

# IMPORTANT: Make sure you update the `DST` variable to match the name of the
# destination backup drive

DST="/Volumes/XSIM2020/SA/asim/"
SRC="/Users/asim"
DST2="/Volumes/XSIM2020/SA/pkg/"
SRC2="/usr/local/pkg"
EXCLUDE="$HOME/.backup_ignore_home"

PROG=$0

# --acls        update the destination ACLs to be the same as the source ACLs
# --archive     turn on archive mode (recursive copy + retain attributes)
# --delete      delete any files that have been deleted locally
# --delete-excluded   delete any files (on DST) that are part of the list of excluded files
# --exclude-from  reference a list of files to exclude
# --hard-links    preserve hard-links
# --one-file-system   don't cross device boundaries (ignore mounted volumes)
# --sparse      handle sparse files efficiently
# --verbose     increase verbosity
# --xattrs		update the remote extended attributes to be the same as the local ones
# --dry-run		dry run

if [ ! -r "$SRC" ]; then
    logger -t $PROG "Source $SRC not readable - Cannot start the sync process"
    exit;
fi

if [ ! -w "$DST" ]; then
    logger -t $PROG "Destination $DST not writeable - Cannot start the sync process"
    exit;
fi

# To save the log into /usr/local/logs
MYDATE=`date +"%F-%H%M"`
BACKUPLOG="/usr/local/logs/backup-home-$MYDATE.txt"
BACKUPLOG2="/usr/local/logs/backup-home2-$MYDATE.txt"

# If you want to log to the system, uncomment the next line
# logger -t $PROG "Start rsync"
echo "Start rsync"

sudo /usr/local/bin/rsync --acls \
           --archive \
           --delete \
           --delete-excluded \
           --exclude-from=$EXCLUDE \
           --hard-links \
           --links \
           --one-file-system \
           --sparse \
           --verbose \
           --xattrs \
           --log-file=$BACKUPLOG \
           "$SRC" "$DST"

sudo /usr/local/bin/rsync --acls \
           --archive \
           --delete \
           --delete-excluded \
           --exclude-from=$EXCLUDE \
           --hard-links \
           --links \
           --one-file-system \
           --sparse \
           --verbose \
           --xattrs \
           --log-file=$BACKUPLOG2 \
           "$SRC2" "$DST2"
# If you want to log to the system, uncomment the next line
# logger -t $PROG "End rsync"
echo "End rsync"

##To Restore
#SRC="/Volumes/XSIM2020/SA/asim"
#DST="/Users/asim/Desktop/Restore/"
#MYDATE=`date +"%F-%H%M"`
#BACKUPLOG="/usr/local/logs/backup-home-$MYDATE.txt"
#sudo /usr/local/bin/rsync \
#           -rlptgD \
#           --hard-links \
#           --links \
#           --one-file-system \
#           --sparse \
#           --verbose \
#           --xattrs \
#           --log-file=$BACKUPLOG \
#           "$SRC" "$DST"

## Make the backup bootable
#sudo bless -folder "$DST"/System/Library/CoreServices
#
#echo "blessed destination"

exit 0
