
Mac OS X bootable backup drive with rsync

### Packing a tar file for home

% tar zcvf ~/Desktop/rsync-home.tar.gz \
    backup_alex.sh \
    backup_connie.sh \
    backup_caitlin.sh \
    backup_ryan.sh \
    backup_ignore_me \
    readme-backup-rsync.txt \
    rsync \
    logs

### Unpacking the tar file

0. Download https://sdm.lbl.gov/asim/rsync-2017-mac.tar.gz
1. Unpack the tar file, or double click the tar file
      tar zxvf backup_rsync_2017_mac.tar.gz
   It creates rsync-2017-mac, and contains the following 4 files:
   rsync, backup_rsync.sh, .backup_ignore, readme-backup-rsync.txt
2. Copy to places by running the following commands in the Terminal:
      sudo cp ./rsync /usr/local/bin
      sudo cp ./backup_rsync.sh /usr/local/bin
      cp .backup_ignore ~
      sudo mkdir /usr/local/logs
3. Follow the instructions in readme-backup-rsync.txt


### Formatting and partitioning the drive

1. Connect the drive to your Mac and open the Disk Utility application
2. Click on the external disk's name.
3. Click on the "Partition" tab.
4. Click on the big pie circle which represents the number of partitions.
5. Select the number of partitions you need with + or - sign. 
   Probably "1 partition" if it is to match your internal disk.
5. Under "Name" enter the volume name you want to use, e.g., "Backup".
6. Under "Format" select "Mac OS X Extended (Journaled)", 
   which is necessary if the disk is to be bootable.
7. Click "Apply".


### Enable ownership permissions

1. Select the mounted drive and view its information page 
   (using "Get Info" or Command+I).
2. Expand the "Sharing & Permissions" section,
   unlock the lock to uncheck "Ignore ownership on this volume", and
   lock it back.


### Backup script

You need to install rsync 3, http://rsync.samba.org.
And, by now, you have this in /usr/local/bin

The following is the contents of a script I've named backup_rsync.sh. 
I'm using it to backup all of the data on my laptop internal disk, 
with a specifed set of exceptions contained 
within a file called $HOME/.backup_ignore.

Make sure you change the destination path in the back up script:
      sudo vi /usr/local/bin/backup_rsync.sh
   Find the line 11: DST="/Volumes/BACKUP2017/" and
   change it to whatever name that you put on the external disk. 


---------------------------------------------------------
#!/bin/bash

# Disc backup script: Requires rsync 3

# Ask for the administrator password upfront
sudo -v

# NOTE: Make sure you update the DST variable to match the name of the
# destination backup drive

DST="/Volumes/BACKUP2017/"
EXCLUDE="$HOME/.backup_ignore"
SRC="/"

PROG=$0

if [ ! -r "$SRC" ]; then
    logger -t $PROG "Source $SRC not readable - Cannot start the sync process"
    exit;
fi

if [ ! -w "$DST" ]; then
    logger -t $PROG "Destination $DST not writeable - Cannot start the sync process"
    exit;
fi

# To save the log into /usr/local/logs
MYDATE=`date +"%F-%H%M"`
BACKUPLOG="/usr/local/logs/backup-$MYDATE.txt"

# If you want to log to the system, uncomment the next line
# logger -t $PROG "Start rsync"
echo "Start rsync"

sudo /usr/local/bin/rsync --acls \
           --archive \
           --delete \
           --delete-excluded \
           --exclude-from=$EXCLUDE \
           --hard-links \
           --links \
           --one-file-system \
           --sparse \
           --verbose \
           --xattrs \
           --log-file=$BACKUPLOG \
           "$SRC" "$DST"

# If you want to log to the system, uncomment the next line
# logger -t $PROG "End rsync"
echo "End rsync"

# Make the backup bootable
sudo bless -folder "$DST"/System/Library/CoreServices

exit 0

---------------------------------------------------------

This is the contents of the $HOME/.backup_ignore file.

---------------------------------------------------------
.Spotlight-*/
.Trashes
/afs/*
/automount/*
/cores/*
/dev/*
/Incompatible Software/*
/Network/*
/private/tmp/*
/private/var/run/*
/private/var/spool/postfix/*
/private/var/vm/*
/Previous Systems.localized
/tmp/*
/usr/local/logs/*
/Volumes/*
*/.Trash
/.DocumentRevisions-V100/*
/.PKInstallSandboxManager/*
/.PKInstallSandboxManager-SystemSoftware/*
/installer.failurerequests
---------------------------------------------------------


Every time the script runs, messages will be written to the designated log folder /usr/local/logs/.

Check that the source (SRC) and destination (DST) paths in the script are correct 
and match the volume name that you chose when partitioning the disk.


### Running the backup script
1. Make sure the script is executable:
   chmod +x /usr/local/bin/backup_rsync.sh
2. In the Terminal (Utilities/Terminal in the Applications),
   run "sudo /usr/local/bin/backup_rsync.sh"


### Checking the disk is bootable

Once you've run the backup script, you should test that the backup disk is bootable. 
To do this, restart your computer and hold down the Alt/Option key. 
Your backup disk should be presented, with the volume name you chose, as a bootable disk. 

If the Terminal displayed the following line during the first boot from the backup:
  dyld: shared cached file was build against a different libSystem.dylib, ignoring cache
the fix for this is to update the cache by entering the following into the Terminal:
  sudo update_dyld_shared_cache -force

That should be everything you need to start implementing an incremental backup strategy when using Mac OS X.

### References
http://www.jwz.org/blog/
http://www.codinghorror.com/blog/2008/01/whats- your-backup-strategy.html
http://nicolasgallagher.com/mac-osx-bootable-backup-drive-with-rsync/
	https://github.com/necolas/dot1les

### To Build

./configure.sh --prefix=/usr/local

