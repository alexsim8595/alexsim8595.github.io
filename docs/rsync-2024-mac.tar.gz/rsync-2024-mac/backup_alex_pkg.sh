#!/bin/bash

sudo -v
#DST2="/Volumes/WD2TSIM2018/SKA/"
DST2="/Volumes/XSIM2020/SA/"
SRC2="/usr/local/pkg"
EXCLUDE="/usr/local/pkg/rsync/mine/backup_ignore_me"
LOGDIR="/usr/local/pkg/rsync/mine/logs"
#EXCLUDE="/usr/local/pkg/rsync-2017-mac/backup_ignore_me"
#LOGDIR="/usr/local/pkg/rsync-2017-mac/logs"

PROG=$0

# To save the log into /usr/local/logs
MYDATE=`date +"%F-%H%M"`
BACKUPLOG2="$LOGDIR/backup-alex-pkg-$MYDATE.txt"

echo "Start rsync"
sudo /usr/local/bin/rsync --acls \
           --archive \
           --delete \
           --delete-excluded \
           --exclude-from=$EXCLUDE \
           --hard-links \
           --links \
           --one-file-system \
           --sparse \
           --verbose \
           --xattrs \
           --log-file=$BACKUPLOG2 \
           "$SRC2" "$DST2"

echo "End rsync"
exit 0
