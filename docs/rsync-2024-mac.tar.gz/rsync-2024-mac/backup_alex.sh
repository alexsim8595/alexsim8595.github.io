#!/bin/bash

sudo -v
#DST="/Volumes/WD2TSIM2018/SKA/"
DST="/Volumes/XSIM2020/SA/"
SRC="/Users/asim"
#DST2="/Volumes/WD2TSIM2018/SKA/"
DST2="/Volumes/XSIM2020/SA/"
SRC2="/usr/local/pkg"
EXCLUDE="/usr/local/pkg/rsync/mine/backup_ignore_me"
LOGDIR="/usr/local/pkg/rsync/mine/logs"
#EXCLUDE="/usr/local/pkg/rsync-2017-mac/backup_ignore_me"
#LOGDIR="/usr/local/pkg/rsync-2017-mac/logs"

PROG=$0

if [ ! -r "$SRC" ]; then
    logger -t $PROG "Source $SRC not readable - Cannot start the sync process"
    exit;
fi

if [ ! -w "$DST" ]; then
    logger -t $PROG "Destination $DST not writeable - Cannot start the sync process"
    exit;
fi

# To save the log into /usr/local/logs
MYDATE=`date +"%F-%H%M"`
BACKUPLOG="$LOGDIR/backup-alex-$MYDATE.txt"
BACKUPLOG2="$LOGDIR/backup-alex-pkg-$MYDATE.txt"

echo "Start rsync"

sudo /usr/local/bin/rsync --acls \
           --archive \
           --delete \
           --delete-excluded \
           --exclude-from=$EXCLUDE \
           --hard-links \
           --links \
           --one-file-system \
           --sparse \
           --verbose \
           --xattrs \
           --log-file=$BACKUPLOG \
           "$SRC" "$DST"

#sudo /usr/local/bin/rsync --acls \
#           --archive \
#           --delete \
#           --delete-excluded \
#           --exclude-from=$EXCLUDE \
#           --hard-links \
#           --links \
#           --one-file-system \
#           --sparse \
#           --verbose \
#           --xattrs \
#           --log-file=$BACKUPLOG2 \
#           "$SRC2" "$DST2"

echo "End rsync"

##To Restore
#SRC="/Volumes/WD2TSIM2018/SKA/asim"
#SRC="/Volumes/XSIM2020/SA/asim"
#DST="/Users/asim/Desktop/Restore/"
#MYDATE=`date +"%F-%H%M"`
#BACKUPLOG="$LOGDIR/backup-restore-alex-$MYDATE.txt"
#sudo /usr/local/bin/rsync \
#           -rlptgD \
#           --hard-links \
#           --links \
#           --one-file-system \
#           --sparse \
#           --verbose \
#           --xattrs \
#           --log-file=$BACKUPLOG \
#           "$SRC" "$DST"

# sudo /usr/local/bin/rsync \
#          --dry-run \
#          --archive \
#          --links \
#          --one-file-system \
#          --verbose \
#          --log-file=./rsync.log.txt \
#          /Volumes/XSIM2020/SA/asim/ \
#          /Users/asim/Desktop/Restore/
# sudo /usr/local/bin/rsync \
#          --archive \
#          --links \
#          --one-file-system \
#          --verbose \
#          --log-file=./rsync.log.txt \
#          /Volumes/XSIM2020/SA/asim/ \
#          /Users/asim/Desktop/Restore/
# sudo /usr/local/bin/rsync \
#          --archive \
#          --links \
#          --one-file-system \
#          --verbose \
#          --exclude-from=./pkg.txt \
#          --log-file=./rsync-pkg.log.txt \
#          /Volumes/XSIM2020/SA/pkg/ \
#          /Users/asim/Desktop/Restore/pkg/


exit 0
