#!/bin/bash

sudo -v
#DST="/Volumes/WD2TSIM2018/SKC/"
DST="/Volumes/XSIM2020/SC/"
SRC="/Users/caitlin"
EXCLUDE="/usr/local/pkg/rsync-2017-mac/backup_ignore_me"
LOGDIR="/usr/local/pkg/rsync-2017-mac/logs"
BINDIR="/usr/local/pkg/rsync-2017-mac"
MYDATE=`date +"%F-%H%M"`
BACKUPLOG="$LOGDIR/backup-caitlin-$MYDATE.txt"

PROG=$0

if [ ! -r "$SRC" ]; then
    logger -t $PROG "Source $SRC not readable - Cannot start the sync process"
    exit;
fi

if [ ! -w "$DST" ]; then
    logger -t $PROG "Destination $DST not writeable - Cannot start the sync process"
    exit;
fi

echo "Start rsync"

sudo $BINDIR/rsync --acls \
           --archive \
           --delete \
           --delete-excluded \
           --exclude-from=$EXCLUDE \
           --hard-links \
           --links \
           --one-file-system \
           --sparse \
           --verbose \
           --xattrs \
           --log-file=$BACKUPLOG \
           "$SRC" "$DST"

echo "End rsync"

##To Restore
#SRC="/Volumes/WD2TSIM2018/SKC/caitlin"
#SRC="/Volumes/XSIM2020/SC/caitlin"
#DST="/Users/caitlin/Desktop/Restore/"
#MYDATE=`date +"%F-%H%M"`
#BACKUPLOG="$LOGDIR/backup-restore-caitlin-$MYDATE.txt"
#sudo $BINDIR/rsync \
#           -rlptgD \
#           --hard-links \
#           --links \
#           --one-file-system \
#           --sparse \
#           --verbose \
#           --xattrs \
#           --log-file=$BACKUPLOG \
#           "$SRC" "$DST"

# sudo $BINDIR/rsync \
#          --dry-run \
#          --archive \
#          --links \
#          --one-file-system \
#          --verbose \
#          --log-file=./rsync.log.txt \
#          /Volumes/XSIM2020/SC/caitlin/ \
#          /Users/caitlin/Desktop/Restore/
# sudo $BINDIR/rsync \
#          --archive \
#          --links \
#          --one-file-system \
#          --verbose \
#          --log-file=./rsync.log.txt \
#          /Volumes/XSIM2020/SC/caitlin/ \
#          /Users/caitlin/Desktop/Restore/


exit 0
