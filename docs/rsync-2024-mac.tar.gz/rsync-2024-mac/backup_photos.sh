#!/bin/bash

sudo -v
#DST2="/Volumes/WD2TSIM2018/SKA/"
#DST2="/Volumes/XSIM2020/SA/"
DST2="/Volumes/BKPHOTOS/Archives/"
#SRC2="/usr/local/pkg"
SRC2="/Users/asim/Pictures"
EXCLUDE="/usr/local/pkg/rsync-2017-mac/backup_ignore_me"
LOGDIR="/usr/local/pkg/rsync-2017-mac/logs"

PROG=$0

# To save the log into /usr/local/logs
MYDATE=`date +"%F-%H%M"`
BACKUPLOG2="$LOGDIR/backup-photos-$MYDATE.txt"

echo "Start rsync Pictures"
sudo /usr/local/bin/rsync --acls \
           --archive \
           --delete \
           --delete-excluded \
           --exclude-from=$EXCLUDE \
           --hard-links \
           --links \
           --one-file-system \
           --sparse \
           --verbose \
           --xattrs \
           --log-file=$BACKUPLOG2 \
           "$SRC2" "$DST2"

echo "End rsync"
exit 0
