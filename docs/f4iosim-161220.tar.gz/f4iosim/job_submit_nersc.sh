#!/bin/sh
#SBATCH --job-name=asim_warp_test
#SBATCH --time=00:10:00
#SBATCH -n 2
#SBATCH --partition=debug
#SBATCH -e asim-%j.err
#SBATCH -o asim-%j.out

export DARSHAN_DISABLE_SHARED_REDUCTION=1
export MPICH_MPIIO_HINTS="*:romio_cb_write=enable:romio_ds_write=disable"
export MPICH_MPIIO_HINTS_DISPLAY=1
#export MPICH_MPIIO_XSTATS=3
export ROMIO_PRINT_HINTS=1

srun -n 2 /scratch2/scratchdirs/asim/flash4/f4iosim/f4iosim -c 2 -t
