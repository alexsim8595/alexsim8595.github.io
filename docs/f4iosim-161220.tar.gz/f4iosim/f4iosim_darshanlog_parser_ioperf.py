'''
/****** Copyright Notice ***
 *
 * PIOK - Parallel I/O Kernels, Copyright (c) 2015-2016, 
 * The Regents of the University of California, through Lawrence
 * Berkeley National Laboratory (subject to receipt of any required
 * approvals from the U.S. Dept. of Energy).  All rights reserved.
 *
 * If you have questions about your rights to use or distribute this
 * software, please contact Berkeley Lab's Innovation & Partnerships Office
 * at  IPO@lbl.gov.
 *
 * NOTICE.  This Software was developed under funding from the U.S.
 * Department of Energy and the U.S. Government consequently retains
 * certain rights. As such, the U.S. Government has been granted for itself
 * and others acting on its behalf a paid-up, nonexclusive, irrevocable,
 * worldwide license in the Software to reproduce, distribute copies to the
 * public, prepare derivative works, and perform publicly and display
 * publicly, and to permit other to do so.
 *
 ****************************/

Alex Sim <ASim@LBL.Gov>
Scientific Data Management Group
Lawrence Berkeley National Laboratory
Thu Dec  1 12:41:41 PST 2016

f4iosim log parser, performance calculator

Application log 
20844935 969935.output

for simulation outputs
96636770400 f4iot-chkpt-0.h5
14495516768 f4iot-plot-0.h5

darshan-3 log with debug info
441285994 darshan_all.txt

### App log
LBNL_F4IO_P : 3 times
LBNL_F4IO_P	INIT_H5WP	4241	294912	36	152676	16
LBNL_F4IO_P	H5WriteP	4241	0.000938	294912	36	152676
LBNL_F4IO_P	H5Dwrite	4241	1.026535	152676
LBNL_F4IO_P	WRITE_PLOT	4241	1.375906	FILE_0	fio0	152676

LBNL_F4IO_C : 10 times
LBNL_F4IO_C	INIT_H5WC	4241	294912	36	152676	16
LBNL_F4IO_C	H5WriteC	4241	0.000809	294912	36	152676
LBNL_F4IO_C	H5Dwrite	4241	2.817595	152676
LBNL_F4IO_C	WRITE_CHKPT	4241	3.880735	FILE_0	fio0	152676

printf ("LBNL_F4IO_P\tINIT_H5WP\t%d\t%d\t%d\t%d\t%d\n", my_rank, total_blocks, local_blocks, global_offset,nxb);
printf ("LBNL_F4IO_P\tH5WriteP\t%d\t%f\t%d\t%d\t%d\n", my_rank, elapsed, total_blocks, local_blocks, global_offset);
printf ("LBNL_F4IO_P\tH5Dwrite\t%d\t%f\t%d\n", my_rank, elapsed, global_offset);
printf ("LBNL_F4IO_P\tWRITE_PLOT\t%d\t%f\tFILE_%d\t%s\t%d\n",  my_rank, elapsed,i,record_label, global_offset);

printf ("LBNL_F4IO_C\tINIT_H5WC\t%d\t%d\t%d\t%d\t%d\n", my_rank, total_blocks, local_blocks, global_offset,nxb);
printf ("LBNL_F4IO_C\tH5WriteC\t%d\t%f\t%d\t%d\t%d\n", my_rank, elapsed, total_blocks, local_blocks, global_offset);
printf ("LBNL_F4IO_C\tH5Dwrite\t%d\t%f\t%d\n", my_rank, elapsed, global_offset);
printf ("LBNL_F4IO_C\tWRITE_CHKPT\t%d\t%f\tFILE_%d\t%s\t%d\n", my_rank, elapsed,i,record_label, global_offset);

'''

import sys, getopt, os, argparse
import time
import datetime
import random
import fileinput
import matplotlib
import matplotlib.pyplot as plt

from datetime import datetime, date, time
from multiprocessing import Process, Queue, current_process, freeze_support, Pool

def search_item(mystype, mytype, mylist):
    return [element for element in mylist if (mytype in element[mystype])]
    
def search_item_flash(mystype, mytype, mylist):
    return [element for element in mylist if element[mystype] == mytype]

mpi_p_t=0.0
mpi_p_r=0.0
mpi_p_p=0.0
mpi_c_t=0.0
mpi_c_r=0.0
mpi_c_p=0.0
mpi_a=0.0
posix_p_t=0.0
posix_p_r=0.0
posix_p_p=0.0
posix_c_t=0.0
posix_c_r=0.0
posix_c_p=0.0
posix_a=0.0
app_p_t=0.0
app_p_r=0.0
app_p_p=0.0
app_c_t=0.0
app_c_r=0.0
app_c_p=0.0
app_a=0.0
#input_file = "/Users/asim/Desktop/flash/runs/cetus-8-160506/darshan_base.txt"
#dirpath="/Users/asim/Desktop/flash/runs/cetus-8-160506"
#f_input_file = "sedov.io.txt"
#input_file = "darsian_all.txt"
input_file = ""
f_input_file = ""
save_flag = False
filesize_flag = 1   # default for maxblocks=50
baseflag=False
app_plot_flag=False
checkpoint_count = 1
plot_count = 1

parser = argparse.ArgumentParser(description='FLASH/DARSHAN3 IO LOG parser')
parser.add_argument("-i", "--input", action="store", dest="input_file", required=True, help="input file path")
parser.add_argument("-s", "--save", action="store_true", dest="save_flag", required=False, help="saving plots")
parser.add_argument("-n", "--num", action="store", dest="filesize_flag", required=False, help="1:1,854,291,968, 2:14,830,141,440, 3:50,048,843,776")
parser.add_argument("-f", "--flashinput", action="store", dest="f_input_file", required=True, help="flash io input file path")
parser.add_argument("-b", "--base", action="store_true", dest="baseflag", required=False, help="darshan base output")
parser.add_argument("-p", "--applot", action="store_true", dest="app_plot_flag", required=False, help="overlayed app io perf plot")

#args = parser.parse_args([
#    '-i', '/Users/asim/Desktop/flash/runs/fio-06-161123/darshan_all-965992.txt',
#    '-f', '/Users/asim/Desktop/flash/runs/fio-06-161123/f4io.txt'])
args = parser.parse_args()     # uncomment this line for general use

input_file = args.input_file
f_input_file = args.f_input_file
if (args.save_flag): 
    save_flag = args.save_flag
if (args.baseflag): 
    baseflag = args.baseflag
if (args.app_plot_flag): 
    app_plot_flag = args.app_plot_flag
if (args.filesize_flag): 
    filesize_flag = int(args.filesize_flag)

if (filesize_flag == 1) :
    # for default
    checkpoint_size = 96636770400 
    plot_size = 14495516768
else : 
#elif (filesize_flag == 6) :
    # 5 for cube32, maxblocks=50, nblockx,y,z=4
    checkpoint_size = 96636770400 
    plot_size = 14495516768


ax = plt.gca()
ax.ticklabel_format(useOffset=False)
ax.get_yaxis().get_major_formatter().set_useOffset(False)

app_beginning_time=""
app_duration=""
if (len(f_input_file) > 0):
    flash_list=[]
    for line in fileinput.input([f_input_file], mode='r'):
        parsed = line.split()
        if (parsed[1] == "H5Dwrite"):
            dt=float(parsed[3])
            rk=int(parsed[2])
            rlist=search_item_flash('rank', rk, flash_list)
            matching = search_item_flash('name', parsed[0], rlist)
            if ((len(rlist) > 0) and (len(matching) > 0)):
                matching[0]['datetime'] += dt
            else:
                flash_dict = {
                    'name': parsed[0],   # LBNL_F4IO_P, LBNL_F4IO_C
                    'rank': rk,  # rank
                    'datetime': dt 
                }
                flash_list.append(flash_dict)
        
    names=[]    # filenames
    xaxis=[]    # start/end time
    yaxis=[]    # duration 
    fplot, (plotp) = plt.subplots(1, sharex=True, figsize=(11, 8))
    plotp.set_title("time vs output files", fontsize=11)
    r_plots = search_item_flash('name', 'LBNL_F4IO_P', flash_list)
    
    print "=============================================================================="
    print "APP plot_rank\ttime\tsize (GB)\tB/sec\tGB/sec"
    total_time = 0  # in microseconds
    total_size = 0  # bytes
    pcount=0
    maxrate=0.0
    maxfile=''
    minrate=8000000000.0
    minfile=''
    f_size = plot_size
    total_size = f_size
    for fi in r_plots:
        pcount+=1
        #t_diff = m_dt-i_dt
        t_diff = fi['datetime']
        o_rate = (float(f_size)/float(t_diff)) # B/sec
        if (o_rate < minrate):
            minrate = o_rate
            minfile = fi['rank']
            total_time = t_diff

    print "Total_plotfile ", total_time, " seconds for ", total_size/1024/1024/1024, "GB =", total_size, "Bytes"
    print "Rate_plotfile ", float(total_size)/float(total_time), "B/sec = ", float(total_size)/float(total_time)/1024/1024/1024, "GB/sec"
    print "------------------------------------------------------------------------------"
    print "APP IO time Plotfile\tGB/s\tGB/s\trank"
    print total_time, "\t", float(total_size)/float(total_time)/1024/1024/1024, "\t", minrate, "\t", minfile
    
    app_p_t=total_time
    app_p_r=float(total_size)/float(total_time)/1024/1024/1024
    app_p_p=minrate

    # for checkpoint
    cr_plots = search_item_flash('name', 'LBNL_F4IO_C', flash_list)

    print "=============================================================================="
    print "APP chkpt_filename\ttime\tsize (GB)\tB/sec\tGB/sec"
    c_total_time = 0  # in microseconds
    c_total_size = 0  # bytes
    maxrate=0.0
    maxfile=''
    minrate=8000000000.0
    minfile=''
    f_size = checkpoint_size
    c_total_size = f_size
    for fi in cr_plots:
        pcount+=1
        t_diff = fi['datetime']
        o_rate = (float(f_size)/float(t_diff)) # B/sec
        if (o_rate < minrate):
            minrate = o_rate
            minfile = fi['rank']
            c_total_time = t_diff
    
    print "Total_chkptfile ", c_total_time, " seconds  for ", c_total_size/1024/1024/1024, "GB =", c_total_size, "Bytes"
    print "Rate_chkptfile ", float(c_total_size)/float(c_total_time), "B/sec = ", float(c_total_size)/float(c_total_time)/1024/1024/1024, "GB/sec"

    print "------------------------------------------------------------------------------"
    print "APP IO Time Chkpt\tGB/s\tGB/s\trank"
    print c_total_time, "\t", float(c_total_size)/float(c_total_time)/1024/1024/1024, "\t", minrate, "\t", minfile
    
    app_c_t=c_total_time
    app_c_r=float(c_total_size)/float(c_total_time)/1024/1024/1024
    app_c_p=minrate
    app_a=float(total_size + c_total_size)/(total_time + c_total_time)/1024/1024/1024
    

    print "=============================================================================="
    print "=============================================================================="
    print "=============================================================================="

###########################################################################
posix_list=[]
posix_hash_list=[]
mpiio_list=[]
mpiio_hash_list=[]
rank=-100
hashname=" "
name=" "
rsize=0
write_time=0.0
meta_time=0.0

for line in fileinput.input([input_file], mode='r'):
    if (len(line) > 1):
        parsed = line.split()
        if (baseflag):
            if (parsed[1] == "-1"):        
                if (parsed[0] == "POSIX"):
                    if (parsed[3] == "POSIX_BYTES_WRITTEN") :
                        hashname=parsed[2]  # 3414876530736194290
                        name=(parsed[5].split('/'))[-1]   # sedov_hdf5_plt_cnt_0001
                        rsize = int(parsed[4])
                
                    if (parsed[3] == "POSIX_F_SLOWEST_RANK_TIME"):
                        start_time = float(parsed[4])
                
                        flash_dict = {
                            'hashname': hashname,  # 13919071261708348485
                            'name': name,   # sedov_hdf5_plt_cnt_0001
                            'time': start_time
                        }
                        posix_list.append(flash_dict)
                        if (hashname not in posix_hash_list):
                            posix_hash_list.append(hashname)

                elif (parsed[0] == "MPI-IO"):
                    if (parsed[3] == "MPIIO_BYTES_WRITTEN") :
                        hashname=parsed[2]  # 3414876530736194290
                        name=(parsed[5].split('/'))[-1]   # sedov_hdf5_plt_cnt_0001
                        rsize = int(parsed[4])
                
                    if (parsed[3] == "MPIIO_F_SLOWEST_RANK_TIME"):
                        start_time = float(parsed[4])
                                
                        flash_dict = {
                            'hashname': hashname,  # 13919071261708348485
                            'name': name,   # sedov_hdf5_plt_cnt_0001
                            'time': start_time
                        }
                        mpiio_list.append(flash_dict)
                        if (hashname not in mpiio_hash_list):
                            mpiio_hash_list.append(hashname)
        else:  
            if (parsed[0] == "POSIX"):
                if (parsed[3] == "POSIX_BYTES_WRITTEN") :
                    rank=int(parsed[1]) # rank
                    hashname=parsed[2]  # 3414876530736194290
                    name=(parsed[5].split('/'))[-1]   # sedov_hdf5_plt_cnt_0001
                    rsize = int(parsed[4])
                
                if (parsed[3] == "POSIX_F_WRITE_TIME"):
                    write_time = float(parsed[4])
                
                if (parsed[3] == "POSIX_F_META_TIME"):
                    meta_time = float(parsed[4])
                
                    flash_dict = {
                        'rank': rank, # rank
                        'hashname': hashname,  # 13919071261708348485
                        'name': name,   # sedov_hdf5_plt_cnt_0001
                        'time': (write_time + meta_time)
                    }
                    posix_list.append(flash_dict)
                    if (hashname not in posix_hash_list):
                        posix_hash_list.append(hashname)
                        #print "POSIX list len = ", len(posix_hash_list)

            elif (parsed[0] == "MPI-IO"):
                if (parsed[3] == "MPIIO_BYTES_WRITTEN") :
                    rank=int(parsed[1]) # rank
                    hashname=parsed[2]  # 3414876530736194290
                    name=(parsed[5].split('/'))[-1]   # sedov_hdf5_plt_cnt_0001
                    rsize = int(parsed[4])
                
                if (parsed[3] == "MPIIO_F_WRITE_TIME"):
                    write_time = float(parsed[4])
                
                if (parsed[3] == "MPIIO_F_META_TIME"):
                    meta_time = float(parsed[4])
                
                    flash_dict = {
                        'rank': rank, # rank
                        'hashname': hashname,  # 13919071261708348485
                        'name': name,   # sedov_hdf5_plt_cnt_0001
                        'time': (write_time + meta_time)
                    }
                    mpiio_list.append(flash_dict)
                    if (hashname not in mpiio_hash_list):
                        mpiio_hash_list.append(hashname)

names=[]    # filenames
xaxis=[]    # start/end time
yaxis=[]    # duration 
r_plots = search_item('name', 'f4iot-plot', posix_list)

print "=============================================================================="
print "POSIX: plot_filename\ttime\tsize (B)\tsize (GB)\tB/sec\tGB/sec"
total_time = 0.0  # in seconds
total_size = 0  # bytes
pcount=0
maxrate=0.0
maxfile=''
minrate=80000000000.0
minfile=''
for fi in posix_hash_list:
    matching = search_item('hashname', fi, r_plots)
    if (len(matching)>0):
        pcount+=1
        time_list = []
        for j in range(0,len(matching)) :
            time_list.append(matching[j]['time'])
        t_diff = max(time_list)
        f_size = plot_size
        total_size += f_size
        o_rate = float(f_size)/float(t_diff) # B/sec
        if (o_rate > maxrate):
            maxrate = o_rate
            maxfile = matching[0]['rank']
        print matching[0]['name'], " " , t_diff, " ", f_size, " ", float(f_size)/1024/1024/1024, " ", o_rate, " ", o_rate/1024/1024/1024
        total_time += t_diff

print "Total_plotfile ", total_time, " seconds for ", total_size/1024/1024/1024, "GB =", total_size, "Bytes"
print "Rate_plotfile ", float(total_size)/float(total_time), "B/sec = ", float(total_size)/float(total_time)/1024/1024/1024, "GB/sec"
print "------------------------------------------------------------------------------"
print "POSIX: IO time \tGB/s\tB/s"
print total_time, "\t", float(total_size)/float(total_time)/1024/1024/1024, "\t", maxrate

posix_p_t=total_time
posix_p_r=float(total_size)/float(total_time)/1024/1024/1024
posix_p_p=maxrate
posix_a=float(total_size)

#########################
# MPIIO plot files
r_plots = search_item('name', 'f4iot-plot', mpiio_list)

print "=============================================================================="
print "MPIIO: plot_filename\ttime\tsize (B)\tsize (GB)\tB/sec\tGB/sec"
total_time = 0.0  # in seconds
total_size = 0  # bytes
pcount=0
maxrate=0.0
maxfile=''
minrate=80000000000.0
minfile=''
for fi in mpiio_hash_list:
    matching = search_item('hashname', fi, r_plots)
    if (len(matching)>0):
        pcount+=1
        time_list = []
        for j in range(0,len(matching)) :
            time_list.append(matching[j]['time'])
        t_diff = max(time_list)
        f_size = plot_size
        total_size += f_size
        o_rate = float(f_size)/float(t_diff) # B/sec
        if (o_rate > maxrate):
            maxrate = o_rate
            maxfile = matching[0]['rank']
        print matching[0]['name'], " " , t_diff, " ", f_size, " ", float(f_size)/1024/1024/1024, " ", o_rate, " ", o_rate/1024/1024/1024
        total_time += t_diff

print "Total_plotfile ", total_time, " seconds for ", total_size/1024/1024/1024, "GB =", total_size, "Bytes"
print "Rate_plotfile ", float(total_size)/float(total_time), "B/sec = ", float(total_size)/float(total_time)/1024/1024/1024, "GB/sec"
print "------------------------------------------------------------------------------"
print "MPIIO: IO time \tGB/s \tB/s"
print total_time, "\t", float(total_size)/float(total_time)/1024/1024/1024, "\t", maxrate

mpi_p_t=total_time
mpi_p_r=float(total_size)/float(total_time)/1024/1024/1024
mpi_p_p=maxrate
mpi_a=total_size

###########################################
# for checkpoint per posix
cr_plots = search_item('name', 'f4iot-chkpt', posix_list)

print "=============================================================================="
print "=============================================================================="
print "=============================================================================="
print "POSIX: chkpt_filename\ttime\tsize (B)\tsize (GB)\tB/sec\tGB/sec"
c_total_time = 0.0  # in seconds
c_total_size = 0  # bytes
c_pcount=pcount
maxrate=0.0
maxfile=''
minrate=80000000000.0
minfile=''
for fi in posix_hash_list:
    matching = search_item('hashname', fi, cr_plots)
    if (len(matching)>0):
        pcount+=1
        time_list = []
        for j in range(0,len(matching)) :
            time_list.append(matching[j]['time'])
        t_diff = max(time_list)
        f_size = checkpoint_size
        c_total_size += f_size
        o_rate = float(f_size)/float(t_diff) # B/sec
        if (o_rate > maxrate):
            maxrate = o_rate
            maxfile = matching[0]['rank']

        print matching[0]['name'], " " , t_diff, " ", f_size, " ", float(f_size)/1024/1024/1024, " ", o_rate, " ", o_rate/1024/1024/1024
        c_total_time += t_diff
        
print "Total_chkptfile ", c_total_time, " seconds  for ", c_total_size/1024/1024/1024, "GB =", c_total_size, "Bytes"
print "Rate_chkptfile ", float(c_total_size)/float(c_total_time), "B/sec = ", float(c_total_size)/float(c_total_time)/1024/1024/1024, "GB/sec"

print "------------------------------------------------------------------------------"
print "POSIX: IO Time \tGB/s \t B/s"
print c_total_time, "\t", float(c_total_size)/float(c_total_time)/1024/1024/1024, "\t", maxrate

posix_c_t=c_total_time
posix_c_r=float(c_total_size)/float(c_total_time)/1024/1024/1024
posix_c_p=maxrate
posix_a=float(posix_a + c_total_size)/float(posix_p_t+posix_c_t)/1024/1024/1024

###########################################
# for checkpoint per mpiio
cr_plots = search_item('name', 'f4iot-chkpt', mpiio_list)

print "=============================================================================="
print "MPIIO: chkpt_filename\ttime\tsize (B)\tsize (GB)\tB/sec\tGB/sec"
c_total_time = 0.0  # in seconds
c_total_size = 0  # bytes
pcount=c_pcount
maxrate=0.0
maxfile=''
minrate=80000000000.0
minfile=''
for fi in mpiio_hash_list:
    matching = search_item('hashname', fi, cr_plots)
    if (len(matching)>0):
        pcount+=1
        time_list = []
        for j in range(0,len(matching)) :
            time_list.append(matching[j]['time'])
        t_diff = max(time_list)
        f_size = checkpoint_size
        c_total_size += f_size
        o_rate = float(f_size)/float(t_diff) # B/sec
        if (o_rate > maxrate):
            maxrate = o_rate
            maxfile = matching[0]['rank']

        print matching[0]['name'], " " , t_diff, " ", f_size, " ", float(f_size)/1024/1024/1024, " ", o_rate, " ", o_rate/1024/1024/1024
        c_total_time += t_diff
        
print "Total_chkptfile ", c_total_time, " seconds  for ", c_total_size/1024/1024/1024, "GB =", c_total_size, "Bytes"
print "Rate_chkptfile ", float(c_total_size)/float(c_total_time), "B/sec = ", float(c_total_size)/float(c_total_time)/1024/1024/1024, "GB/sec"

print "------------------------------------------------------------------------------"
print "MPIIO: IO Time \tGB/s \tB/s"
print c_total_time, "\t", float(c_total_size)/float(c_total_time)/1024/1024/1024, "\t", maxrate

mpi_c_t=c_total_time
mpi_c_r=float(c_total_size)/float(c_total_time)/1024/1024/1024
mpi_c_p=maxrate
mpi_a=float(mpi_a + c_total_size)/float(mpi_p_t+mpi_c_t)/1024/1024/1024

print "=============================================================================="
print "#######################################################################"
print "M Time Plotfile\tM GB/s Plotfile\tM Peak Plotfile\tM Time Chkpt\tM GB/s Chkpt\tM Peak Chkpt\tM ave GB/s\tP Time Plotfile\tP GB/s Plotfile\tP Peak Plotfile\tP Time Chkpt\tP GB/s Chkpt\tP Peak Chkpt\tP ave GB/s\tA Time Plotfile\tA GB/s Plotfile\tA Peak Plotfile\tA Time Chkpt\tA GB/s Chkpt\tA Peak Chkpt\tA ave GB/s"
print mpi_p_t, "\t", mpi_p_r, "\t", mpi_p_p, "\t", mpi_c_t, "\t", mpi_c_r, "\t", mpi_c_p, "\t", mpi_a, "\t", posix_p_t, "\t", posix_p_r, "\t", posix_p_p, "\t", posix_c_t, "\t", posix_c_r, "\t", posix_c_p, "\t", posix_a, "\t", app_p_t, "\t", app_p_r, "\t", app_p_p, "\t", app_c_t, "\t", app_c_r, "\t", app_c_p, "\t", app_a

